# Zubair Zubi

* pkg update
* pkg upgrade
* pkg install python
* pkg install python2
* pkg install nodejs
* pip2 install mechanize
* pip2 install requests
* pkg install git
* git clone https://github.com/zubi-143/file2.git
* cd file2
* python2 zzbrand.py

* OWNER = ZUBAIR ZUBI
* NOW ENJOY SUCCESSFUL CLONING
